﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace shop_management_system
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            
        }

        private void Fruits_CheckedChanged(object sender, EventArgs e)
        {
           
        }

 
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            radioButton1.ForeColor = System.Drawing.Color.Green;
            radioButton2.ForeColor = System.Drawing.Color.Red;

            cmb_items.Items.Clear();
            cmb_items.Items.Add("Mango");
            cmb_items.Items.Add("Apple");
            cmb_items.Items.Add("Peach");
            cmb_items.Items.Add("Water Melon");
            cmb_items.Items.Add("Banana"); 


        }

        private void radioButton2_CheckedChanged_1(object sender, EventArgs e)
        {
            radioButton1.ForeColor = System.Drawing.Color.Red;
            radioButton2.ForeColor = System.Drawing.Color.Green;

            cmb_items.Items.Clear();
            cmb_items.Items.Add("Tamato");
            cmb_items.Items.Add("Patato");
            cmb_items.Items.Add("Onion");
            cmb_items.Items.Add("Egg Plant");
            cmb_items.Items.Add("Cauliflower");
        }

        private void cmb_items_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_items.SelectedItem.ToString() == "Mango")
            {
                
                txtprice.Text = "50";
            }
            else if (cmb_items.SelectedItem.ToString() == "Apple")
            {
                txtprice.Text = "200";
            }
            else if (cmb_items.SelectedItem.ToString() == "Peach")
            {
                txtprice.Text = "120";
            }
            else if (cmb_items.SelectedItem.ToString() == "Water Melon")
            {
                txtprice.Text = "80";
            }
            else if (cmb_items.SelectedItem.ToString() == "Banana")
            {
                txtprice.Text = "110";
            }
            else if (cmb_items.SelectedItem.ToString() == "Tamato")
            {
                txtprice.Text = "50";
            }
            else if (cmb_items.SelectedItem.ToString() == "Patato")
            {
                txtprice.Text = "200";
            }
            else if (cmb_items.SelectedItem.ToString() == "Onion")
            {
                txtprice.Text = "120";
            }
            else if (cmb_items.SelectedItem.ToString() == "Egg Plant")
            {
                txtprice.Text = "80";
            }
            else if (cmb_items.SelectedItem.ToString() == "Cauliflower")
            {
                txtprice.Text = "110";
            }
            else
            {
                txtprice.Text = "0";
            }
            txttotal.Text = "";
            txtquantity.Text = "";
        }

        private void txtquantity_TextChanged(object sender, EventArgs e)
        {
            if (txtquantity.Text.Length > 0)
            {
                txttotal.Text = (Convert.ToInt16(txtprice.Text) * Convert.ToInt16(txtquantity.Text)).ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] arr = new string[4];
            arr[0] = cmb_items.SelectedItem.ToString();
            arr[1] = txtprice.Text;
            arr[2] = txtquantity.Text;
            arr[3] = txttotal.Text;

            ListViewItem lvi = new ListViewItem(arr);

            listView1.Items.Add(lvi);

            txtsub.Text=(Convert.ToInt16(txtsub.Text)+ Convert.ToInt16(txttotal.Text)).ToString();
        }

        private void txtdiscount_TextChanged(object sender, EventArgs e)
        {
        if(txtdiscount.Text.Length > 0)
            {
                txtnet.Text = (Convert.ToInt16(txtsub.Text) - Convert.ToInt16(txtdiscount.Text)).ToString();
            }
        }

        private void txtpaid_TextChanged(object sender, EventArgs e)
        {
            if(txtpaid.Text.Length >0 )
            {
                txtbalance.Text = (Convert.ToInt16(txtnet.Text) - Convert.ToInt16(txtpaid.Text)).ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(listView1.SelectedItems.Count > 0)
            {
                for(int i=0; i< listView1.Items.Count; i++)
                {
                    if(listView1.Items[i].Selected)
                    {
                        txtsub.Text = (Convert.ToInt16(txtsub.Text) - Convert.ToInt16(listView1.Items[i].SubItems[3].Text)).ToString();
                        listView1.Items[i].Remove();
                    }
                }
            }
        }

    }
}
`
