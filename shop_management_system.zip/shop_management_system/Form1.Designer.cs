﻿namespace shop_management_system
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cmb_items = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtprice = new System.Windows.Forms.TextBox();
            this.txtquantity = new System.Windows.Forms.TextBox();
            this.txttotal = new System.Windows.Forms.TextBox();
            this.txt_price = new System.Windows.Forms.Label();
            this.txt_quantity = new System.Windows.Forms.Label();
            this.txt_total = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtsub = new System.Windows.Forms.TextBox();
            this.txt_sub = new System.Windows.Forms.Label();
            this.txt_discount = new System.Windows.Forms.Label();
            this.txtdiscount = new System.Windows.Forms.TextBox();
            this.txt_net = new System.Windows.Forms.Label();
            this.txtnet = new System.Windows.Forms.TextBox();
            this.txt_paid = new System.Windows.Forms.Label();
            this.txtpaid = new System.Windows.Forms.TextBox();
            this.txt_balance = new System.Windows.Forms.Label();
            this.txtbalance = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(517, 80);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // cmb_items
            // 
            this.cmb_items.FormattingEnabled = true;
            this.cmb_items.Location = new System.Drawing.Point(217, 136);
            this.cmb_items.Name = "cmb_items";
            this.cmb_items.Size = new System.Drawing.Size(312, 21);
            this.cmb_items.TabIndex = 1;
            this.cmb_items.SelectedIndexChanged += new System.EventHandler(this.cmb_items_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(146, 139);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Select Items";
            // 
            // txtprice
            // 
            this.txtprice.Location = new System.Drawing.Point(27, 200);
            this.txtprice.Name = "txtprice";
            this.txtprice.Size = new System.Drawing.Size(100, 20);
            this.txtprice.TabIndex = 7;
            this.txtprice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtquantity
            // 
            this.txtquantity.Location = new System.Drawing.Point(172, 200);
            this.txtquantity.Name = "txtquantity";
            this.txtquantity.Size = new System.Drawing.Size(100, 20);
            this.txtquantity.TabIndex = 8;
            this.txtquantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtquantity.TextChanged += new System.EventHandler(this.txtquantity_TextChanged);
            // 
            // txttotal
            // 
            this.txttotal.Location = new System.Drawing.Point(323, 200);
            this.txttotal.Name = "txttotal";
            this.txttotal.Size = new System.Drawing.Size(100, 20);
            this.txttotal.TabIndex = 9;
            this.txttotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_price
            // 
            this.txt_price.AutoSize = true;
            this.txt_price.Location = new System.Drawing.Point(24, 184);
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(31, 13);
            this.txt_price.TabIndex = 10;
            this.txt_price.Text = "Price";
            // 
            // txt_quantity
            // 
            this.txt_quantity.AutoSize = true;
            this.txt_quantity.Location = new System.Drawing.Point(169, 184);
            this.txt_quantity.Name = "txt_quantity";
            this.txt_quantity.Size = new System.Drawing.Size(46, 13);
            this.txt_quantity.TabIndex = 11;
            this.txt_quantity.Text = "Quantity";
            // 
            // txt_total
            // 
            this.txt_total.AutoSize = true;
            this.txt_total.Location = new System.Drawing.Point(320, 184);
            this.txt_total.Name = "txt_total";
            this.txt_total.Size = new System.Drawing.Size(31, 13);
            this.txt_total.TabIndex = 12;
            this.txt_total.Text = "Total";
            this.txt_total.Click += new System.EventHandler(this.label4_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(454, 200);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 13;
            this.button1.Text = "Add Items";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtsub
            // 
            this.txtsub.Location = new System.Drawing.Point(81, 372);
            this.txtsub.Name = "txtsub";
            this.txtsub.Size = new System.Drawing.Size(100, 20);
            this.txtsub.TabIndex = 15;
            this.txtsub.Text = "0";
            this.txtsub.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_sub
            // 
            this.txt_sub.AutoSize = true;
            this.txt_sub.Location = new System.Drawing.Point(22, 375);
            this.txt_sub.Name = "txt_sub";
            this.txt_sub.Size = new System.Drawing.Size(53, 13);
            this.txt_sub.TabIndex = 16;
            this.txt_sub.Text = "Sub Total";
            // 
            // txt_discount
            // 
            this.txt_discount.AutoSize = true;
            this.txt_discount.Location = new System.Drawing.Point(198, 376);
            this.txt_discount.Name = "txt_discount";
            this.txt_discount.Size = new System.Drawing.Size(49, 13);
            this.txt_discount.TabIndex = 18;
            this.txt_discount.Text = "Discount";
            // 
            // txtdiscount
            // 
            this.txtdiscount.Location = new System.Drawing.Point(253, 376);
            this.txtdiscount.Name = "txtdiscount";
            this.txtdiscount.Size = new System.Drawing.Size(100, 20);
            this.txtdiscount.TabIndex = 17;
            this.txtdiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtdiscount.TextChanged += new System.EventHandler(this.txtdiscount_TextChanged);
            // 
            // txt_net
            // 
            this.txt_net.AutoSize = true;
            this.txt_net.Location = new System.Drawing.Point(399, 379);
            this.txt_net.Name = "txt_net";
            this.txt_net.Size = new System.Drawing.Size(24, 13);
            this.txt_net.TabIndex = 20;
            this.txt_net.Text = "Net";
            // 
            // txtnet
            // 
            this.txtnet.Location = new System.Drawing.Point(429, 376);
            this.txtnet.Name = "txtnet";
            this.txtnet.Size = new System.Drawing.Size(100, 20);
            this.txtnet.TabIndex = 19;
            this.txtnet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_paid
            // 
            this.txt_paid.AutoSize = true;
            this.txt_paid.Location = new System.Drawing.Point(395, 405);
            this.txt_paid.Name = "txt_paid";
            this.txt_paid.Size = new System.Drawing.Size(28, 13);
            this.txt_paid.TabIndex = 22;
            this.txt_paid.Text = "Paid";
            // 
            // txtpaid
            // 
            this.txtpaid.Location = new System.Drawing.Point(429, 402);
            this.txtpaid.Name = "txtpaid";
            this.txtpaid.Size = new System.Drawing.Size(100, 20);
            this.txtpaid.TabIndex = 21;
            this.txtpaid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtpaid.TextChanged += new System.EventHandler(this.txtpaid_TextChanged);
            // 
            // txt_balance
            // 
            this.txt_balance.AutoSize = true;
            this.txt_balance.Location = new System.Drawing.Point(377, 427);
            this.txt_balance.Name = "txt_balance";
            this.txt_balance.Size = new System.Drawing.Size(46, 13);
            this.txt_balance.TabIndex = 24;
            this.txt_balance.Text = "Balance";
            // 
            // txtbalance
            // 
            this.txtbalance.Location = new System.Drawing.Point(429, 428);
            this.txtbalance.Name = "txtbalance";
            this.txtbalance.Size = new System.Drawing.Size(100, 20);
            this.txtbalance.TabIndex = 23;
            this.txtbalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.listView1.FullRowSelect = true;
            this.listView1.Location = new System.Drawing.Point(27, 258);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(502, 108);
            this.listView1.TabIndex = 14;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Item Name";
            this.columnHeader1.Width = 250;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Price";
            this.columnHeader2.Width = 75;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Quantity";
            this.columnHeader3.Width = 75;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Total";
            this.columnHeader4.Width = 75;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(169, 98);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(50, 17);
            this.radioButton1.TabIndex = 25;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Fruits";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(275, 98);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(78, 17);
            this.radioButton2.TabIndex = 26;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Vegatables";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(447, 229);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(82, 23);
            this.button2.TabIndex = 27;
            this.button2.Text = "Remove item";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(81, 416);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(64, 21);
            this.button3.TabIndex = 28;
            this.button3.Text = "Save";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(169, 416);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(64, 21);
            this.button4.TabIndex = 29;
            this.button4.Text = "Clear";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(262, 416);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(64, 21);
            this.button5.TabIndex = 30;
            this.button5.Text = "Print";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(541, 449);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.txt_balance);
            this.Controls.Add(this.txtbalance);
            this.Controls.Add(this.txt_paid);
            this.Controls.Add(this.txtpaid);
            this.Controls.Add(this.txt_net);
            this.Controls.Add(this.txtnet);
            this.Controls.Add(this.txt_discount);
            this.Controls.Add(this.txtdiscount);
            this.Controls.Add(this.txt_sub);
            this.Controls.Add(this.txtsub);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txt_total);
            this.Controls.Add(this.txt_quantity);
            this.Controls.Add(this.txt_price);
            this.Controls.Add(this.txttotal);
            this.Controls.Add(this.txtquantity);
            this.Controls.Add(this.txtprice);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmb_items);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "shop management system";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox cmb_items;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtprice;
        private System.Windows.Forms.TextBox txtquantity;
        private System.Windows.Forms.TextBox txttotal;
        private System.Windows.Forms.Label txt_price;
        private System.Windows.Forms.Label txt_quantity;
        private System.Windows.Forms.Label txt_total;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtsub;
        private System.Windows.Forms.Label txt_sub;
        private System.Windows.Forms.Label txt_discount;
        private System.Windows.Forms.TextBox txtdiscount;
        private System.Windows.Forms.Label txt_net;
        private System.Windows.Forms.TextBox txtnet;
        private System.Windows.Forms.Label txt_paid;
        private System.Windows.Forms.TextBox txtpaid;
        private System.Windows.Forms.Label txt_balance;
        private System.Windows.Forms.TextBox txtbalance;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
    }
}

